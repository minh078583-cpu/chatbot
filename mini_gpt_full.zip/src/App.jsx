
import MiniGpt from "./MiniGpt";
export default function App() { return <MiniGpt /> }
